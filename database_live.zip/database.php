<?php
$link=mysqli_connect('localhost','d17393_suman','d17393_suman','d17393_suman');
mysqli_set_charset($link, 'utf8mb4'); 
?>
