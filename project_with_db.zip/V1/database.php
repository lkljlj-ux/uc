<?php
$link=mysqli_connect('localhost','onlines3_testupdate','onlines3_testupdate','onlines3_testupdate');
mysqli_set_charset($link, 'utf8mb4');
?>
